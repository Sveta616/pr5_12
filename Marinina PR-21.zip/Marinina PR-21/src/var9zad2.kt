
fun main()
{
    try{
        print("введите трехзначное число: ")
        var num1=readLine()!!.toInt()
        var num2=num1/100
        var num3=(num1%100)%10
        when
        {
            (num2==num3)->
                    println("верно")
            else->println("неверно")
        }
    }
    catch(e:Exception)
    {
        println("введите число")
    }
}