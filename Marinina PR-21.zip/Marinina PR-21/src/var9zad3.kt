

fun main() {
try{
    val D=IntArray(3);
    val N=IntArray(3);
   var k=0;
    println("введите доступное кол-во дней")
    var y=readLine()!!.toInt()
    println("введите кол-во денежных средств")
    var x=readLine()!!.toInt()
    for (i in 0 until 3)
    {
        if (y>D[i])
        {
           if (x>N[i])
           {
             k++
           }
        }
    }
    println()
    when(k)
    {
        1->println("турсит может взять 1 из 3 путёвок")
        2->println("турсит может взять 2 из 3 путёвок")
        3->println("турсит может взять 3 из 3 путёвок")
    }
}
catch(e:Exception)
{
    println("введите число")
}
    }





