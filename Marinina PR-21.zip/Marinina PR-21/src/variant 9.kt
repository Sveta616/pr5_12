import kotlin.math.round
    fun main(){
        try{
            println("введите число")
            var x=readLine()!!.toDouble()
            when{
                (x>3.6)->println((45*x*x+5))
                (x<=3)->println((5*x/(10*x*x+1)))


            }
        }
        catch (e:Exception) {
            println("введите число")
        }
    }

