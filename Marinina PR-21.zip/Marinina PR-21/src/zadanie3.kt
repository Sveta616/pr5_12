fun main()
{
try{
    print("введите число: ")
    var num=readLine()!!.toInt()
    when
    {
        (num>=0)&&(num<=2)->
            println("младенец")
        (num>=3)&&(num<=12)->
                println("ребёнок")
        (num>=11)&&(num<=17)->
            println("подросток")
        (num>=18)&&(num<=30)->
            println("средний возраст")
        (num>=31)&&(num<=64)->
            println("взрослый")
        (num>=65)->
            println("пенсионер")
        else->("введите ещё раз,так нельзя")
    }
}catch(e:Exception)
{
 println("введите число")

}
}